
exports = module.exports = {
    "DB": {
        "NAME": process.env.ENV_TESTING ? "shopdb-test" : "shopdb",
        "USERNAME": "shopper",
        "PASSWORD": "shopper",
        "HOST": "localhost"
    },
    "ONEAUTH": {
        "CLIENT_ID": "8330703919",
        "CLIENT_SECRET": "0yiHAzFy0QfCy4hNljDM2Adl3oa4OOhv03f2bNcxBw4SYEx87UhGGKUAdH5qp2zT"
    }
}