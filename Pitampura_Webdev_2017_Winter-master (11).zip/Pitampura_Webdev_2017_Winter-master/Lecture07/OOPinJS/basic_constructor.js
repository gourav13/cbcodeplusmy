function Person (name, age) {
    this.name = name
    this.age = age
}

let p = new Person("Arnav", 24)
