# Steps for Deploying

1) Create this as github repository

2) Create a GitHub project

3) Push this repository to github

4) Make sure the website has an index.html

5) Go to repository settings on Github

6) Enable Github Pages

7) Add CNAME in the repository for using custom domains