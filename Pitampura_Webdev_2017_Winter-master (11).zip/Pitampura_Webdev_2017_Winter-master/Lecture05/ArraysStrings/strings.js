let str = "This is a string"
console.log(str.indexOf('is', 4))
console.log(str.lastIndexOf('i', 12))

console.log(str.charAt(6))

str.substr(5, 7) //"is a st"
str.substring(5,7) //"is"

console.log(str.split(' '))