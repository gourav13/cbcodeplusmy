let x = {
    alpha: 222,
    beta: 'hello'
}

let y
