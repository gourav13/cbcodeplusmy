console.log(typeof 10) //number
console.log(typeof 10.1) //number
console.log(typeof 'a') //string
console.log(typeof "wow") //string
console.log(typeof false) //boolean
console.log(typeof [1,2,3]) //object
console.log(typeof {a: 10, b: 'a'}) //object
console.log(typeof undefined) //undefined
console.log(typeof null) //object


