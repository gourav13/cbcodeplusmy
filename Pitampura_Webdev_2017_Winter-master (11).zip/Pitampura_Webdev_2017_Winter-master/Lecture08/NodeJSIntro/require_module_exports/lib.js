module.exports = exports = {
    hello () {
        return "hello"
    },
    a: 10
}