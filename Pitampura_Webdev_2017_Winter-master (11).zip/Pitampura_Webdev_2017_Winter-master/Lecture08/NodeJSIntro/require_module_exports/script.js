const lib = require('./lib')

console.log(lib.a)
console.log(lib.hello())
