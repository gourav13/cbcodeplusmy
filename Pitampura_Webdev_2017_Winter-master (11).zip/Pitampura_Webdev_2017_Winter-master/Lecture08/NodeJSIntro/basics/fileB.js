const fileA = require('./fileA')

console.log(fileA.a())