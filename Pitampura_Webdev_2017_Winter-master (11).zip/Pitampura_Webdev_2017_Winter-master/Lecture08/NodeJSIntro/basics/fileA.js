function someFunction () {
    return "some thing"
}
// NEVER DO THIS
//global.someFunction = someFunction

exports.a = someFunction