console.log(process.argv)

