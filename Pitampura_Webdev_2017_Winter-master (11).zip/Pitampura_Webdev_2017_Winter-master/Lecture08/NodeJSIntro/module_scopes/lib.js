let secret = "wont tell"

module.exports = exports = {
    showSecret () {
        return secret
    }
}