const lib = require('./lib')

console.log(lib.secret)
console.log(lib.showSecret())