const lib = require('./lib')

console.log(lib)