module.exports = exports = {
    c: 30
}